create function timestamptypmodin(cstring[]) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptypmodin$$;

comment on function timestamptypmodin(cstring[]) is 'I/O typmod';

alter function timestamptypmodin(cstring[]) owner to rdsadmin;

