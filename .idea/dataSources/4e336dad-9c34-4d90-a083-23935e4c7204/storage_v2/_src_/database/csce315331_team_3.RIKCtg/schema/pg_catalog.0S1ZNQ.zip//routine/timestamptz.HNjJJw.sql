create function timestamptz(date) returns timestamp with time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$date_timestamptz$$;

comment on function timestamptz(timestamp with time zone, integer) is 'adjust timestamptz precision';

alter function timestamptz(timestamp with time zone, integer) owner to rdsadmin;

