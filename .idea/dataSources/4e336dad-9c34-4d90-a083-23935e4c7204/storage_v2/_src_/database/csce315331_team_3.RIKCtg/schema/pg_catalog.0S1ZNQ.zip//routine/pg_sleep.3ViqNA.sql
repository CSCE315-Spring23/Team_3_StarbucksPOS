create function pg_sleep(double precision) returns void
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_sleep$$;

comment on function pg_sleep(double precision) is 'sleep for the specified time in seconds';

alter function pg_sleep(double precision) owner to rdsadmin;

