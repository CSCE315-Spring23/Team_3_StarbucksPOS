create function int8out(bigint) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int8out$$;

comment on function int8out(bigint) is 'I/O';

alter function int8out(bigint) owner to rdsadmin;

