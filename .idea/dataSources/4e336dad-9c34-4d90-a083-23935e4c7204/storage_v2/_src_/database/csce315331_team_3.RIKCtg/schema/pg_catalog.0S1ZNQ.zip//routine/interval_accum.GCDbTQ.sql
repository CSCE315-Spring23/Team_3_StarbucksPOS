create function interval_accum(interval[], interval) returns interval[]
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$interval_accum$$;

comment on function interval_accum(interval[], interval) is 'aggregate transition function';

alter function interval_accum(interval[], interval) owner to rdsadmin;

