create function to_timestamp(double precision) returns timestamp with time zone
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float8_timestamptz$$;

comment on function to_timestamp(double precision) is 'convert UNIX epoch to timestamptz';

alter function to_timestamp(double precision) owner to rdsadmin;

