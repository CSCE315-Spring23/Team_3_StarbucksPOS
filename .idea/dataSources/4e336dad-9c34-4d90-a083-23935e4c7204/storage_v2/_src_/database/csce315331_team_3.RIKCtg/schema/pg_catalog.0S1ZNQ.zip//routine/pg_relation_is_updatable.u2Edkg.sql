create function pg_relation_is_updatable(regclass, boolean) returns integer
    stable
    strict
    parallel safe
    cost 10
    language internal
as
$$pg_relation_is_updatable$$;

comment on function pg_relation_is_updatable(regclass, boolean) is 'is a relation insertable/updatable/deletable';

alter function pg_relation_is_updatable(regclass, boolean) owner to rdsadmin;

