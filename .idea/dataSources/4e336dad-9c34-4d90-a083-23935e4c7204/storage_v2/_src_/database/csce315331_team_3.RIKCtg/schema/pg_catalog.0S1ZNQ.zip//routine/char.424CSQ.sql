create function char(integer) returns "char"
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$i4tochar$$;

comment on function char(integer) is 'convert int4 to char';

alter function char(integer) owner to rdsadmin;

