create function bit_recv(internal, oid, integer) returns bit
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bit_recv$$;

comment on function bit_recv(internal, oid, integer) is 'I/O';

alter function bit_recv(internal, oid, integer) owner to rdsadmin;

