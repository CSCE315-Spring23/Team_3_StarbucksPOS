create function likejoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$likejoinsel$$;

comment on function likejoinsel(internal, oid, internal, smallint, internal) is 'join selectivity of LIKE';

alter function likejoinsel(internal, oid, internal, smallint, internal) owner to rdsadmin;

