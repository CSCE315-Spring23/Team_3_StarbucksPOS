create function trunc(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dtrunc$$;

comment on function trunc(double precision) is 'truncate to integer';

alter function trunc(double precision) owner to rdsadmin;

