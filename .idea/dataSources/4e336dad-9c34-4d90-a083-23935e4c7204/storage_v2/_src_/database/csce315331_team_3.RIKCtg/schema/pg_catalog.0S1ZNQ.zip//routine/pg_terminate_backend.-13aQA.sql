create function pg_terminate_backend(integer) returns boolean
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_terminate_backend$$;

comment on function pg_terminate_backend(integer) is 'terminate a server process';

alter function pg_terminate_backend(integer) owner to rdsadmin;

