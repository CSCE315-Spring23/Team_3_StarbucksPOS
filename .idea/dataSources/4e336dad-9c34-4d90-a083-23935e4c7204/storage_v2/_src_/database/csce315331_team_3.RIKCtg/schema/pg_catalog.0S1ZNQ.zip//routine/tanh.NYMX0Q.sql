create function tanh(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dtanh$$;

comment on function tanh(double precision) is 'hyperbolic tangent';

alter function tanh(double precision) owner to rdsadmin;

