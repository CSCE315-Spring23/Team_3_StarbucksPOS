create function circle(point, double precision) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cr_circle$$;

comment on function circle(box) is 'convert box to circle';

alter function circle(box) owner to rdsadmin;

