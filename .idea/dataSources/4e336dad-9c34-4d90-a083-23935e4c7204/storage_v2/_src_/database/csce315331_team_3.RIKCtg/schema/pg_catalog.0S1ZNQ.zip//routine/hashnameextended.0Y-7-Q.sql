create function hashnameextended(name, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashnameextended$$;

comment on function hashnameextended(name, bigint) is 'hash';

alter function hashnameextended(name, bigint) owner to rdsadmin;

