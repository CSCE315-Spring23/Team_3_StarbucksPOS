create function float8_corr(double precision[]) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float8_corr$$;

comment on function float8_corr(double precision[]) is 'aggregate final function';

alter function float8_corr(double precision[]) owner to rdsadmin;

