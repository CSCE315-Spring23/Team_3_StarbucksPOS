create function boolsend(boolean) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$boolsend$$;

comment on function boolsend(boolean) is 'I/O';

alter function boolsend(boolean) owner to rdsadmin;

