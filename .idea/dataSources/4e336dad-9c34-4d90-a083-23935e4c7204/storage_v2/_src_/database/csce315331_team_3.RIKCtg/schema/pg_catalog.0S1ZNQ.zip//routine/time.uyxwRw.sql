create function time(timestamp without time zone) returns time without time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamp_time$$;

comment on function time(timestamp with time zone) is 'convert timestamp with time zone to time';

alter function time(timestamp with time zone) owner to rdsadmin;

