create function int4_accum_inv(internal, integer) returns internal
    immutable
    parallel safe
    cost 1
    language internal
as
$$int4_accum_inv$$;

comment on function int4_accum_inv(internal, integer) is 'aggregate transition function';

alter function int4_accum_inv(internal, integer) owner to rdsadmin;

