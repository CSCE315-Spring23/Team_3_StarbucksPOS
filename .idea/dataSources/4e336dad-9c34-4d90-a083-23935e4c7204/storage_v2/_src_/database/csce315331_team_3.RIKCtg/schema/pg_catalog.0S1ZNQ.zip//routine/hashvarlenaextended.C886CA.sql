create function hashvarlenaextended(internal, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashvarlenaextended$$;

comment on function hashvarlenaextended(internal, bigint) is 'hash';

alter function hashvarlenaextended(internal, bigint) owner to rdsadmin;

