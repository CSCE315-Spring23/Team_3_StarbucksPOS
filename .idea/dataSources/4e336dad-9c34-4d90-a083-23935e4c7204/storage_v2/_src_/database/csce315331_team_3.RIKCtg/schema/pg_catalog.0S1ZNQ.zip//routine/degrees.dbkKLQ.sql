create function degrees(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$degrees$$;

comment on function degrees(double precision) is 'radians to degrees';

alter function degrees(double precision) owner to rdsadmin;

