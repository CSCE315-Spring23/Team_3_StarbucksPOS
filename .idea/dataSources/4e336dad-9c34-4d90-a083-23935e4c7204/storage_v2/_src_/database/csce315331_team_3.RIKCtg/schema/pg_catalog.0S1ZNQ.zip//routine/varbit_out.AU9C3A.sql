create function varbit_out(bit varying) returns cstring
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$varbit_out$$;

comment on function varbit_out(bit varying) is 'I/O';

alter function varbit_out(bit varying) owner to rdsadmin;

