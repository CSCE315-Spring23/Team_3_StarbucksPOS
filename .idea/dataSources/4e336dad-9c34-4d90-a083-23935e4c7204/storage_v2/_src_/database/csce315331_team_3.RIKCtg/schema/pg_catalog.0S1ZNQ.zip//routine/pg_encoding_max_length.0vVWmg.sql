create function pg_encoding_max_length(integer) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_encoding_max_length_sql$$;

comment on function pg_encoding_max_length(integer) is 'maximum octet length of a character in given encoding';

alter function pg_encoding_max_length(integer) owner to rdsadmin;

