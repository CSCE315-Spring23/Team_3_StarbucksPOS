create function float4um(real) returns real
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float4um$$;

comment on function float4um(real) is 'implementation of - operator';

alter function float4um(real) owner to rdsadmin;

