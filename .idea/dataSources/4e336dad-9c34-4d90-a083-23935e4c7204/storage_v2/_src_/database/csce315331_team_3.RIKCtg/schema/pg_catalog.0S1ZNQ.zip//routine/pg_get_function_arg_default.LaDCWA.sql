create function pg_get_function_arg_default(oid, integer) returns text
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_get_function_arg_default$$;

comment on function pg_get_function_arg_default(oid, integer) is 'function argument default';

alter function pg_get_function_arg_default(oid, integer) owner to rdsadmin;

