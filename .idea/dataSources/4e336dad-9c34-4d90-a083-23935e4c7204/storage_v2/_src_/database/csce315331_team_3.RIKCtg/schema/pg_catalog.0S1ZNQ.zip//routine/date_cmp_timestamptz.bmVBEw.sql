create function date_cmp_timestamptz(date, timestamp with time zone) returns integer
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$date_cmp_timestamptz$$;

comment on function date_cmp_timestamptz(date, timestamp with time zone) is 'less-equal-greater';

alter function date_cmp_timestamptz(date, timestamp with time zone) owner to rdsadmin;

