create function timetz(timestamp with time zone) returns time with time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_timetz$$;

comment on function timetz(time, int4) is 'convert time to time with time zone';

alter function timetz(time, int4) owner to rdsadmin;

