create function date_trunc(text, timestamp with time zone) returns timestamp with time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$timestamptz_trunc$$;

comment on function date_trunc(text, timestamp with time zone) is 'truncate timestamp with time zone to specified units';

alter function date_trunc(text, timestamp with time zone) owner to rdsadmin;

