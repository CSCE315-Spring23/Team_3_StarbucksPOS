create function interval_in(cstring, oid, integer) returns interval
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$interval_in$$;

comment on function interval_in(cstring, oid, integer) is 'I/O';

alter function interval_in(cstring, oid, integer) owner to rdsadmin;

