create function neqjoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$neqjoinsel$$;

comment on function neqjoinsel(internal, oid, internal, smallint, internal) is 'join selectivity of <> and related operators';

alter function neqjoinsel(internal, oid, internal, smallint, internal) owner to rdsadmin;

