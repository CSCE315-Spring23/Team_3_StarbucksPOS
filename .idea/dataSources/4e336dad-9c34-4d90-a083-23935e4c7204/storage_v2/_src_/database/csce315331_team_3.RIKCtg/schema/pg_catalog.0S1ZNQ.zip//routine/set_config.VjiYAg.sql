create function set_config(text, text, boolean) returns text
    cost 1
    language internal
as
$$set_config_by_name$$;

comment on function set_config(text, text, boolean) is 'SET X as a function';

alter function set_config(text, text, boolean) owner to rdsadmin;

