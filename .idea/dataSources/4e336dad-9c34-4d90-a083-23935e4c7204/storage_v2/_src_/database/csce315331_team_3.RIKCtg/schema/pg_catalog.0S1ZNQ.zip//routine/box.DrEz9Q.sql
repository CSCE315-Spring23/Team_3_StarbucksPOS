create function box(point, point) returns box
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$points_box$$;

comment on function box(point, point) is 'convert point to empty box';

alter function box(point, point) owner to rdsadmin;

