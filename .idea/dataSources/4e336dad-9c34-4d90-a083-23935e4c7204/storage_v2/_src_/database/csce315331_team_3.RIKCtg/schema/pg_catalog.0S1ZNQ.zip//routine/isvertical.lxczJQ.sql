create function isvertical(point, point) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$point_vert$$;

comment on function isvertical(line, point) is 'vertical';

alter function isvertical(line, point) owner to rdsadmin;

