create function varchar(name) returns character varying
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$name_text$$;

comment on function varchar(name, int4, bool) is 'convert name to varchar';

alter function varchar(name, int4, bool) owner to rdsadmin;

