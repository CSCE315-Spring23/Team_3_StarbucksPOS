create function int8_sum(numeric, bigint) returns numeric
    immutable
    parallel safe
    cost 1
    language internal
as
$$int8_sum$$;

comment on function int8_sum(numeric, bigint) is 'aggregate transition function';

alter function int8_sum(numeric, bigint) owner to rdsadmin;

