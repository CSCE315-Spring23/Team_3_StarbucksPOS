create function float8_var_samp(double precision[]) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$float8_var_samp$$;

comment on function float8_var_samp(double precision[]) is 'aggregate final function';

alter function float8_var_samp(double precision[]) owner to rdsadmin;

