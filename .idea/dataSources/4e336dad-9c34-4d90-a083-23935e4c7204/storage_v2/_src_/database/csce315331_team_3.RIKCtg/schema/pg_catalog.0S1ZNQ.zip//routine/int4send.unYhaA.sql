create function int4send(integer) returns bytea
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int4send$$;

comment on function int4send(integer) is 'I/O';

alter function int4send(integer) owner to rdsadmin;

