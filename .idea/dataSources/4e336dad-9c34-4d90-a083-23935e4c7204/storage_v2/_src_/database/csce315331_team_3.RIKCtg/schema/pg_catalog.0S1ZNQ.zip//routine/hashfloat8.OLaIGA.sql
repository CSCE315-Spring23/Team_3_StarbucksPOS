create function hashfloat8(double precision) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashfloat8$$;

comment on function hashfloat8(double precision) is 'hash';

alter function hashfloat8(double precision) owner to rdsadmin;

