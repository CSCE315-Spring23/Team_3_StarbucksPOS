create function bit_in(cstring, oid, integer) returns bit
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$bit_in$$;

comment on function bit_in(cstring, oid, integer) is 'I/O';

alter function bit_in(cstring, oid, integer) owner to rdsadmin;

