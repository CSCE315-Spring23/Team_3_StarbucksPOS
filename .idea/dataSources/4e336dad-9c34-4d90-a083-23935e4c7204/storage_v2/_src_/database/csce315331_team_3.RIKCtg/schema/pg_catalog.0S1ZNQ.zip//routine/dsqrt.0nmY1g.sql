create function dsqrt(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dsqrt$$;

comment on function dsqrt(double precision) is 'implementation of |/ operator';

alter function dsqrt(double precision) owner to rdsadmin;

