create function num_nulls(VARIADIC "any") returns integer
    immutable
    parallel safe
    cost 1
    language internal
as
$$pg_num_nulls$$;

comment on function num_nulls("any") is 'count the number of NULL arguments';

alter function num_nulls("any") owner to rdsadmin;

