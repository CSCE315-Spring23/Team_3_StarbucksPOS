create function floor(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dfloor$$;

comment on function floor(double precision) is 'nearest integer <= value';

alter function floor(double precision) owner to rdsadmin;

