create function get_bit(bytea, integer) returns integer
    language internal
as
$$byteaGetBit$$;

comment on function get_bit(bytea, int4) is 'get bit';

