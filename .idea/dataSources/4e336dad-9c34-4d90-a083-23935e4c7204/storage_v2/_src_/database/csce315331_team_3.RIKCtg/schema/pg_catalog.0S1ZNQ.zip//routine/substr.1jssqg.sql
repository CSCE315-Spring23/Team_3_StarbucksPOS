create function substr(text, integer, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$text_substr$$;

comment on function substr(bytea, integer, int4) is 'extract portion of string';

alter function substr(bytea, integer, int4) owner to rdsadmin;

