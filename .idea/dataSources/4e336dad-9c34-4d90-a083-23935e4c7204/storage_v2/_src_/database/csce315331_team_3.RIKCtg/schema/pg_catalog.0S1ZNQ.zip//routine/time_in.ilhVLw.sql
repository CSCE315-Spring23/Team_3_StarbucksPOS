create function time_in(cstring, oid, integer) returns time without time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$time_in$$;

comment on function time_in(cstring, oid, integer) is 'I/O';

alter function time_in(cstring, oid, integer) owner to rdsadmin;

