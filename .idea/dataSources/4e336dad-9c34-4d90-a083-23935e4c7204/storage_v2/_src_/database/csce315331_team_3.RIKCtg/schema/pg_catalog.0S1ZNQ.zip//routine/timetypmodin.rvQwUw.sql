create function timetypmodin(cstring[]) returns integer
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$timetypmodin$$;

comment on function timetypmodin(cstring[]) is 'I/O typmod';

alter function timetypmodin(cstring[]) owner to rdsadmin;

