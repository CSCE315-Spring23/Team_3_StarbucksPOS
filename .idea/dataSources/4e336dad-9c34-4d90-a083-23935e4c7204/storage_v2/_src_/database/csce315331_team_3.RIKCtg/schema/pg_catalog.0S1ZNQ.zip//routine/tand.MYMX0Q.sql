create function tand(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dtand$$;

comment on function tand(double precision) is 'tangent, degrees';

alter function tand(double precision) owner to rdsadmin;

