create function lo_open(oid, integer) returns integer
    strict
    cost 1
    language internal
as
$$be_lo_open$$;

comment on function lo_open(oid, integer) is 'large object open';

alter function lo_open(oid, integer) owner to rdsadmin;

