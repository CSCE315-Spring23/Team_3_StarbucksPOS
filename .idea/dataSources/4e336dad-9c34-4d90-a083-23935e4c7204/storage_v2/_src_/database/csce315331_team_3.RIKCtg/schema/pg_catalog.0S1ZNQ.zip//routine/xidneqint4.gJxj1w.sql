create function xidneqint4(xid, integer) returns boolean
    immutable
    leakproof
    strict
    parallel safe
    cost 1
    language internal
as
$$xidneq$$;

comment on function xidneqint4(xid, integer) is 'implementation of <> operator';

alter function xidneqint4(xid, integer) owner to rdsadmin;

