create function numeric_fac(bigint) returns numeric
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$numeric_fac$$;

comment on function numeric_fac(bigint) is 'implementation of ! operator';

alter function numeric_fac(bigint) owner to rdsadmin;

