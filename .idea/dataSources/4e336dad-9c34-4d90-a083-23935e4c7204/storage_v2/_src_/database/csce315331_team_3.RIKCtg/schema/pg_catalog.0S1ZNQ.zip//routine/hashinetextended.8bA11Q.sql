create function hashinetextended(inet, bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$hashinetextended$$;

comment on function hashinetextended(inet, bigint) is 'hash';

alter function hashinetextended(inet, bigint) owner to rdsadmin;

