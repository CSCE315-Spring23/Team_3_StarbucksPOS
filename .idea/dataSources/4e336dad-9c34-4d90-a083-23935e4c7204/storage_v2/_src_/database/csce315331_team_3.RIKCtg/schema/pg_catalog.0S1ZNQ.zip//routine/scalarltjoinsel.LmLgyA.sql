create function scalarltjoinsel(internal, oid, internal, smallint, internal) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$scalarltjoinsel$$;

comment on function scalarltjoinsel(internal, oid, internal, smallint, internal) is 'join selectivity of < and related operators on scalar datatypes';

alter function scalarltjoinsel(internal, oid, internal, smallint, internal) owner to rdsadmin;

