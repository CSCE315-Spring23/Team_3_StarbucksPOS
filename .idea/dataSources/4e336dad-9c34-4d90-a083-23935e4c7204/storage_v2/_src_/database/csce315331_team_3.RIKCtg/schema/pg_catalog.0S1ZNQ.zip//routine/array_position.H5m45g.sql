create function array_position(anyarray, anyelement) returns integer
    immutable
    parallel safe
    cost 1
    language internal
as
$$array_position$$;

comment on function array_position(anyarray, anyelement, integer) is 'returns an offset of value in array with start index';

alter function array_position(anyarray, anyelement, integer) owner to rdsadmin;

