create function sin(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$dsin$$;

comment on function sin(double precision) is 'sine';

alter function sin(double precision) owner to rdsadmin;

