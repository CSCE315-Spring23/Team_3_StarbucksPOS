create function circle(point, double precision) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cr_circle$$;

comment on function circle(point, double precision) is 'convert point and radius to circle';

alter function circle(point, double precision) owner to rdsadmin;

