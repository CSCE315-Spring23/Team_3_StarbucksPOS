create function radians(double precision) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$radians$$;

comment on function radians(double precision) is 'degrees to radians';

alter function radians(double precision) owner to rdsadmin;

