create function ishorizontal(point, point) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$point_horiz$$;

comment on function ishorizontal(line, point) is 'horizontal';

alter function ishorizontal(line, point) owner to rdsadmin;

