create function circle(point, double precision) returns circle
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cr_circle$$;

comment on function circle(polygon, float8) is 'convert polygon to circle';

alter function circle(polygon, float8) owner to rdsadmin;

