create function box(point, point) returns box
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$points_box$$;

comment on function box(circle) is 'convert circle to box';

alter function box(circle) owner to rdsadmin;

