create function isfinite(date) returns boolean
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$date_finite$$;

comment on function isfinite(interval) is 'finite interval?';

alter function isfinite(interval) owner to rdsadmin;

