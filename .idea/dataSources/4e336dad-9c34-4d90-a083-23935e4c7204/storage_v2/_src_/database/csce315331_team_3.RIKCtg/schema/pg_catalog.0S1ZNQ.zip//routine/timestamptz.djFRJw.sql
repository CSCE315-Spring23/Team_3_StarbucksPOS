create function timestamptz(date) returns timestamp with time zone
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$date_timestamptz$$;

comment on function timestamptz(timestamp, int4) is 'convert timestamp to timestamp with time zone';

alter function timestamptz(timestamp, int4) owner to rdsadmin;

