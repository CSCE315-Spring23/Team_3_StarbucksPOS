create function pg_has_role(name, name, text) returns boolean
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$pg_has_role_name_name$$;

comment on function pg_has_role(name, text, text) is 'current user privilege on role by role name';

alter function pg_has_role(name, text, text) owner to rdsadmin;

