create function likesel(internal, oid, internal, integer) returns double precision
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$likesel$$;

comment on function likesel(internal, oid, internal, integer) is 'restriction selectivity of LIKE';

alter function likesel(internal, oid, internal, integer) owner to rdsadmin;

