create function money(numeric) returns money
    stable
    strict
    parallel safe
    cost 1
    language internal
as
$$numeric_cash$$;

comment on function money(bigint) is 'convert int8 to money';

alter function money(bigint) owner to rdsadmin;

