create function int8(integer) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int48$$;

comment on function int8(integer) is 'convert int4 to int8';

alter function int8(integer) owner to rdsadmin;

