create function int8inc(bigint) returns bigint
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$int8inc$$;

comment on function int8inc(bigint) is 'increment';

alter function int8inc(bigint) owner to rdsadmin;

