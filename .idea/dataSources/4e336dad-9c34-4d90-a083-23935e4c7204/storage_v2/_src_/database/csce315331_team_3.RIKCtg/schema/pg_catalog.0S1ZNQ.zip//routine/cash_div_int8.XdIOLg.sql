create function cash_div_int8(money, bigint) returns money
    immutable
    strict
    parallel safe
    cost 1
    language internal
as
$$cash_div_int8$$;

comment on function cash_div_int8(money, bigint) is 'implementation of / operator';

alter function cash_div_int8(money, bigint) owner to rdsadmin;

